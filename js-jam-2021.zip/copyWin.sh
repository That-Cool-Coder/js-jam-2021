shopt -s extglob
rm ../../localhost/js-jam-2021/ -r
mkdir ../../localhost/js-jam-2021/
cp -r !(git) ../../localhost/js-jam-2021