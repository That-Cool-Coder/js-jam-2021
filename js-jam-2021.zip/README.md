# js-jam-2021

My entry into the [Gamedev.js Jam 2021](https://itch.io/jam/gamedevjs-2021)

It's written in JS, not made in an engine then exported. ("A true JS game")

Please keep everything themed in greyscale.