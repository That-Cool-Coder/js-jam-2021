class Range {
    constructor(min, max) {
        this.min = min;
        this.max = max;
    }
}