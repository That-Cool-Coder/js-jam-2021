const levelList = [level1, level2, level3, level4, level5,
    level6, level7, level8, level9, level10];